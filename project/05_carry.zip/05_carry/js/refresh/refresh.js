$(function(){
    $('.type').typed({
        strings:["당신의 여행을 함께합니다."],
        typeSpeed:150, //타이핑속도
        backDelay:300,
        loop: true //false는 한번만 실행
    });
});